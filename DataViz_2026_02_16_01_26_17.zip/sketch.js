function setup() {
  background(0)
  createCanvas(900, 1130);
  // load json data and store in variable test
  test = loadJSON('https://api.exchangerate-api.com/v4/latest/USD')
}

function draw() {
  background(0)

  // make sure data is loaded, if not, cancel drawing
  if( test === undefined ) return

  // convert dictionary to flat array of values
  const rates = Object.values( test.rates )
  
  console.log(min(rates))
  console.log(max(rates))
  console.log(rates.length)
          
  strokeWeight(10)
  

  // loop through rates and visualize
  for( let i = 0; i < rates.length; i++ ) {
    //point ((i*5)+60, norm(rates[i], log(min(rates)), log(max(rates)))+10)
    
    if (map (rates[i], min(rates), max(rates), 10, 990) < 11) {
      stroke('green')
    }else if (map (rates[i], min(rates), max(rates), 10, 990) < 15){
      stroke ('orange')
    }else if (map (rates[i], min(rates), max(rates), 10, 990) < 100){
      stroke ('yellow')
    }else stroke('red')
    
    point ((i*5)+10, map (rates[i], min(rates), max(rates), 10, 1120))
    //text (rates[i], (i*5)+50, map (rates[i], min(rates), max(rates), 10, 390))
    
  }
  
  

  // only draw once
  noLoop()
}